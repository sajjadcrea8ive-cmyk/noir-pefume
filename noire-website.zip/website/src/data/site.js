// Single source of truth for brand copy and navigation.
export const site = {
  name: 'NOIRÉ',
  tagline: 'The art of scent.',
  nav: [
    { label: 'Manifesto', href: '#manifesto' },
    { label: 'Collection', href: '#collection' },
    { label: 'Experience', href: '#scent' },
    { label: 'Campaign', href: '#campaign' },
    { label: 'Contact', href: '#contact' },
  ],
}
