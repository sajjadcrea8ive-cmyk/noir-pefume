import Header from './components/layout/Header'
import Hero from './components/sections/Hero/Hero'

export default function App() {
  return (
    <>
      <Header />
      <main>
        <Hero />
      </main>
    </>
  )
}
