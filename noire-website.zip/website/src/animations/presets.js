import { gsap, EASE, DURATION } from './gsap-setup'

// Slide targets up from below while fading in.
export function revealUp(targets, options = {}) {
  return gsap.from(targets, {
    y: 40,
    autoAlpha: 0,
    duration: DURATION.base,
    ease: EASE.cinematic,
    stagger: 0.12,
    ...options,
  })
}

// Plain fade in.
export function fadeIn(targets, options = {}) {
  return gsap.from(targets, {
    autoAlpha: 0,
    duration: DURATION.base,
    ease: EASE.soft,
    ...options,
  })
}
