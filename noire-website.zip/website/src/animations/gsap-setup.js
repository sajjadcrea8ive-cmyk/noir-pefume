// Import gsap, ScrollTrigger and useGSAP from THIS file, never straight from
// the packages. That way plugins are registered exactly once.
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'

gsap.registerPlugin(ScrollTrigger, useGSAP)

// Mobile browsers resize the viewport when the address bar hides.
// Ignoring that stops pinned sections from jumping.
ScrollTrigger.config({ ignoreMobileResize: true })

// Shared easing, so every section "feels" the same.
export const EASE = {
  cinematic: 'expo.out',
  smooth: 'power3.inOut',
  soft: 'power2.out',
}

// Shared durations (seconds).
export const DURATION = {
  fast: 0.6,
  base: 1.2,
  slow: 1.8,
}

// Media queries for gsap.matchMedia(): one place, no typos.
export const MQ = {
  motion: '(prefers-reduced-motion: no-preference)',
  reduce: '(prefers-reduced-motion: reduce)',
  desktop: '(min-width: 768px)',
}

export { gsap, ScrollTrigger, useGSAP }
