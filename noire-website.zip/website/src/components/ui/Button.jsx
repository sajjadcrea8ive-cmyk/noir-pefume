const base =
  'inline-flex items-center justify-center gap-3 font-body text-eyebrow uppercase tracking-[0.28em] transition-colors duration-500 ease-cinematic'

const variants = {
  outline: 'border border-accent/60 px-8 py-4 text-text hover:bg-accent hover:text-bg',
  solid: 'bg-accent px-8 py-4 text-bg hover:bg-text',
  link: 'border-b border-accent/40 pb-1 text-accent hover:border-accent',
}

// Renders an <a> when you pass href, otherwise a <button>.
export default function Button({ variant = 'outline', href, className = '', children, ...props }) {
  const Tag = href ? 'a' : 'button'
  return (
    <Tag
      href={href}
      className={`${base} ${variants[variant]} ${className}`}
      {...(href ? {} : { type: 'button' })}
      {...props}
    >
      {children}
    </Tag>
  )
}
