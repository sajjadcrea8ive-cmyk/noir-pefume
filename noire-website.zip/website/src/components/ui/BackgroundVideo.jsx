import { useEffect, useRef, useState } from 'react'
import { useReducedMotion } from '../../hooks/useMediaQuery'

/**
 * Full-bleed background video with safe fallbacks.
 * You get a still image instead of the video when:
 *  - the person prefers reduced motion
 *  - the browser has Data Saver turned on
 *  - the video fails to load, or autoplay is blocked
 * The video plays once (no loop) and holds its last frame.
 */
export default function BackgroundVideo({ sources, poster, fallback }) {
  const reduced = useReducedMotion()
  const videoRef = useRef(null)
  const [failed, setFailed] = useState(false)
  const saveData = typeof navigator !== 'undefined' && navigator.connection?.saveData === true
  const showImage = reduced || saveData || failed

  useEffect(() => {
    if (showImage) return
    const video = videoRef.current
    if (!video) return
    video.muted = true // required for autoplay on mobile browsers
    video.play().catch(() => setFailed(true))
  }, [showImage])

  const fill = 'absolute inset-0 h-full w-full object-cover'

  if (showImage) {
    return <img src={fallback} alt="" className={fill} />
  }

  return (
    <video
      ref={videoRef}
      className={fill}
      poster={poster}
      autoPlay
      muted
      playsInline
      preload="auto"
      aria-hidden="true"
      tabIndex={-1}
      onError={() => setFailed(true)}
    >
      {sources.map((s) => (
        <source key={s.src} src={s.src} type={s.type} />
      ))}
    </video>
  )
}
