/**
 * Splits text into letters so GSAP can animate each one.
 * Each letter sits inside an overflow-hidden "mask", so it can rise
 * up from below like it is being revealed. Screen readers skip this
 * (aria-hidden); put the real text in an aria-label on the parent.
 */
export default function SplitLetters({ text, className = '', ...props }) {
  return (
    <span aria-hidden="true" className={className} {...props}>
      {[...text].map((char, i) => (
        <span
          key={i}
          className="inline-block overflow-hidden py-[0.16em] -my-[0.16em] align-bottom"
        >
          <span data-letter className="inline-block will-change-transform">
            {char}
          </span>
        </span>
      ))}
    </span>
  )
}
