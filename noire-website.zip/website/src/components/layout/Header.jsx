import { useEffect, useRef, useState } from 'react'
import { site } from '../../data/site'
import { gsap, useGSAP, EASE } from '../../animations/gsap-setup'
import { useMediaQuery, useReducedMotion } from '../../hooks/useMediaQuery'
import Container from './Container'

export default function Header() {
  const [open, setOpen] = useState(false)
  const headerRef = useRef(null)
  const reduced = useReducedMotion()
  const isDesktop = useMediaQuery('(min-width: 768px)')

  // Fade in after the Hero intro. We animate ONLY opacity: a transform on a
  // parent would break the position:fixed mobile menu inside it.
  useGSAP(
    () => {
      if (reduced) return
      gsap.fromTo(
        headerRef.current,
        { autoAlpha: 0 },
        { autoAlpha: 1, duration: 1.4, delay: 2.6, ease: EASE.soft },
      )
    },
    { dependencies: [reduced] },
  )

  // Escape closes the menu, and the page cannot scroll behind it.
  useEffect(() => {
    if (!open) return
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open])

  // If the window grows to desktop size, make sure the menu is closed.
  useEffect(() => {
    if (isDesktop) setOpen(false)
  }, [isDesktop])

  const linkClass =
    'text-eyebrow uppercase tracking-[0.28em] text-text/80 transition-colors duration-500 ease-cinematic hover:text-accent'

  return (
    <header ref={headerRef} className="fixed inset-x-0 top-0 z-50">
      <Container className="relative z-50 flex items-center justify-between py-5 md:py-7">
        <a href="#hero" className="font-display text-2xl font-light tracking-[0.18em]" aria-label={`${site.name} — back to top`}>
          {site.name}
        </a>

        <nav aria-label="Main" className="hidden items-center gap-10 md:flex">
          {site.nav.map((item) => (
            <a key={item.href} href={item.href} className={linkClass}>
              {item.label}
            </a>
          ))}
        </nav>

        <button
          type="button"
          className="text-eyebrow uppercase tracking-[0.28em] md:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? 'Close' : 'Menu'}
        </button>
      </Container>

      {/* Full-screen mobile menu. `inert` hides it from keyboard and screen readers while closed. */}
      <div
        id="mobile-menu"
        inert={!open}
        className={`fixed inset-0 z-40 flex flex-col justify-center bg-bg transition-opacity duration-700 ease-cinematic md:hidden ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      >
        <nav aria-label="Mobile" className="flex flex-col gap-6 px-(--gutter)">
          {site.nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="font-display text-4xl font-light tracking-wide transition-colors hover:text-accent"
            >
              {item.label}
            </a>
          ))}
        </nav>
      </div>
    </header>
  )
}
