// Shared side margins and max width, so every section lines up.
export default function Container({ as: Tag = 'div', className = '', children, ...props }) {
  return (
    <Tag
      className={`mx-auto w-full max-w-(--max-width) px-(--gutter) ${className}`}
      {...props}
    >
      {children}
    </Tag>
  )
}
