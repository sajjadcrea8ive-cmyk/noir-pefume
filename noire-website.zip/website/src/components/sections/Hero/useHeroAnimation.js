import { gsap, useGSAP, EASE, MQ } from '../../../animations/gsap-setup'

/**
 * All Hero motion lives here, so Hero.jsx stays about layout.
 *
 * 1) INTRO  (plays once on load)
 *    curtain fades -> video pushes in -> letters rise -> tagline -> scroll cue
 * 2) PINNED SCROLL  (scrubbed by the scrollbar)
 *    the hero stays fixed while you scroll 120% of a screen:
 *    video pushes in + drifts up, wordmark splits apart, then everything
 *    fades into the page background.
 *
 * gsap.matchMedia() lets us give different behaviour to
 * desktop / mobile / reduced-motion without messy if-statements.
 */
export function useHeroAnimation(rootRef) {
  useGSAP(
    () => {
      const q = gsap.utils.selector(rootRef)
      const el = {
        media: q('[data-hero-media]'),
        zoom: q('[data-hero-zoom]'),
        curtain: q('[data-hero-curtain]'),
        dim: q('[data-hero-dim]'),
        letters: q('[data-letter]'),
        left: q('[data-wm-left]'),
        right: q('[data-wm-right]'),
        tagline: q('[data-hero-tagline]'),
        cue: q('[data-hero-cue]'),
      }

      const mm = gsap.matchMedia()

      // Reduced motion: no intro, no pin. Show the finished state.
      mm.add(MQ.reduce, () => {
        gsap.set(el.curtain, { autoAlpha: 0 })
      })

      mm.add({ motion: MQ.motion, desktop: MQ.desktop }, (ctx) => {
        const { desktop, motion } = ctx.conditions
        // With an object of conditions GSAP runs this when ANY of them match,
        // so a reduced-motion person on a wide screen lands here too. Stop them.
        if (!motion) return

        // ---------- 1) INTRO ----------
        gsap.set(el.letters, { yPercent: 115 })
        gsap.set(el.tagline, { autoAlpha: 0, y: 16 })
        gsap.set(el.cue, { autoAlpha: 0 })

        gsap
          .timeline({ delay: 0.2, defaults: { ease: EASE.cinematic } })
          .to(el.curtain, { autoAlpha: 0, duration: 1.8, ease: 'power2.inOut' }, 0)
          .fromTo(el.zoom, { scale: 1.12 }, { scale: 1, duration: 4, ease: 'power2.out' }, 0)
          .to(el.letters, { yPercent: 0, duration: 1.7, stagger: 0.1 }, 0.9)
          .to(el.tagline, { autoAlpha: 1, y: 0, duration: 1.3 }, 2.1)
          .to(el.cue, { autoAlpha: 1, duration: 1.2, ease: 'power2.out' }, 2.7)

        // ---------- 2) PINNED SCROLL ----------
        const scroll = gsap.timeline({
          defaults: { ease: 'none' },
          scrollTrigger: {
            trigger: rootRef.current,
            start: 'top top',
            end: '+=120%',
            pin: true,
            scrub: 1,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        })

        scroll
          // push-in + subtle parallax drift
          .to(el.media, { scale: 1.18, yPercent: -4, duration: 1 }, 0)
          // soften the picture as we leave it
          .to(el.dim, { opacity: 0.35, duration: 0.7 }, 0)
          .to(el.tagline, { autoAlpha: 0, y: -24, duration: 0.25 }, 0)
          .to(el.cue, { autoAlpha: 0, duration: 0.15 }, 0)

        if (desktop) {
          // The wordmark splits open around the bottle
          scroll
            .to(el.left, { xPercent: -45, duration: 0.8 }, 0)
            .to(el.right, { xPercent: 45, duration: 0.8 }, 0)
            .to([el.left, el.right], { autoAlpha: 0, duration: 0.3 }, 0.55)
        } else {
          // Phones: the wordmark simply drifts up and fades
          scroll.to([el.left, el.right], { y: -30, autoAlpha: 0, duration: 0.4 }, 0.15)
        }

        // Melt into the page background so the next section joins seamlessly
        scroll.to(el.dim, { opacity: 1, duration: 0.3 }, 0.7)
      })
    },
    { scope: rootRef },
  )
}
