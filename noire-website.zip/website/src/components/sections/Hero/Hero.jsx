import { useRef } from 'react'
import { site } from '../../../data/site'
import Container from '../../layout/Container'
import BackgroundVideo from '../../ui/BackgroundVideo'
import SplitLetters from '../../ui/SplitLetters'
import { useHeroAnimation } from './useHeroAnimation'

const VIDEO_SOURCES = [
  { src: '/media/video/hero.webm', type: 'video/webm' },
  { src: '/media/video/hero.mp4', type: 'video/mp4' },
]

// The wordmark is split in two so it can open around the bottle on desktop.
const [LEFT, RIGHT] = [site.name.slice(0, 3), site.name.slice(3)] // "NOI" + "RÉ"

export default function Hero() {
  const rootRef = useRef(null)
  useHeroAnimation(rootRef)

  return (
    <section
      ref={rootRef}
      id="hero"
      aria-label={`${site.name}. ${site.tagline}`}
      className="relative h-svh min-h-[34rem] w-full overflow-hidden bg-bg text-text"
    >
      {/* Layer 1: video (outer = scroll motion, inner = intro motion) */}
      <div data-hero-media className="absolute inset-0 will-change-transform max-md:-top-[7svh] max-md:bottom-[7svh]">
        <div data-hero-zoom className="absolute inset-0">
          <BackgroundVideo
            sources={VIDEO_SOURCES}
            poster="/media/images/hero-poster.webp"
            fallback="/media/images/hero-end.webp"
          />
        </div>
      </div>

      {/* Layer 2: vignette + bottom fade keep text readable and edges dark */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(10,10,10,0.7)_100%)]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-[38%] bg-gradient-to-t from-bg via-bg/60 to-transparent"
      />

      {/* Layer 3: scroll darkening + exit fade (starts invisible) */}
      <div data-hero-dim aria-hidden="true" className="pointer-events-none absolute inset-0 bg-bg opacity-0" />

      {/* Layer 4: intro curtain (starts solid, fades away on load) */}
      <div data-hero-curtain aria-hidden="true" className="absolute inset-0 bg-bg" />

      {/* Layer 5: text */}
      <Container className="relative h-full">
        <h1
          aria-label={site.name}
          className="absolute inset-x-(--gutter) bottom-[11svh] flex justify-center font-display text-[clamp(3rem,17vw,6rem)] font-light uppercase leading-none tracking-[0.06em] md:bottom-auto md:top-1/2 md:grid md:-translate-y-1/2 md:grid-cols-[1fr_var(--wm-gap)_1fr] md:items-center md:text-[clamp(5rem,12vw,13rem)] md:[--wm-gap:26vw]"
        >
          <SplitLetters data-wm-left text={LEFT} className="whitespace-nowrap md:col-start-1 md:justify-self-end" />
          <SplitLetters data-wm-right text={RIGHT} className="whitespace-nowrap md:col-start-3 md:justify-self-start" />
        </h1>

        <p
          data-hero-tagline
          className="absolute inset-x-0 bottom-[5svh] text-center font-display text-xl tracking-[0.12em] text-accent md:inset-x-auto md:bottom-[6svh] md:left-(--gutter) md:text-left md:text-2xl"
        >
          {site.tagline}
        </p>

        <div
          data-hero-cue
          aria-hidden="true"
          className="absolute bottom-[6svh] right-(--gutter) hidden items-center gap-4 text-eyebrow uppercase tracking-[0.35em] text-text/60 md:flex"
        >
          <span>Scroll</span>
          <span className="relative h-12 w-px overflow-hidden bg-text/20">
            <span className="absolute inset-x-0 top-0 h-1/2 animate-[cue_2.4s_ease-in-out_infinite] bg-accent" />
          </span>
        </div>
      </Container>
    </section>
  )
}
