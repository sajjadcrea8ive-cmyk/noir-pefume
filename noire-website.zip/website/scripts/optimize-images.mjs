// Converts the source images into responsive WebP files.
// Run with:  npm run media
// Input : assets-source/*.webp  (these are really JPEGs with a .webp name)
// Output: public/media/images/<name>-<width>.webp
import sharp from 'sharp'
import { mkdir, readdir } from 'node:fs/promises'
import path from 'node:path'

const SRC = 'assets-source'
const OUT = 'public/media/images'
const WIDTHS = [640, 1280, 1920]
const QUALITY = 78

await mkdir(OUT, { recursive: true })

// Files ending in -src are the hero stills, handled separately below.
const files = (await readdir(SRC)).filter(
  (f) => /\.(webp|jpe?g|png)$/i.test(f) && !path.parse(f).name.endsWith('-src'),
)

for (const file of files) {
  const name = path.parse(file).name
  for (const width of WIDTHS) {
    const out = path.join(OUT, `${name}-${width}.webp`)
    await sharp(path.join(SRC, file))
      .resize({ width, withoutEnlargement: true })
      .webp({ quality: QUALITY })
      .toFile(out)
  }
  console.log('done:', name)
}

// Hero stills (extracted from the video with ffmpeg) go through the same pipeline.
for (const [input, output] of [
  ['hero-poster-src.png', 'hero-poster.webp'],
  ['hero-end-src.png', 'hero-end.webp'],
]) {
  try {
    await sharp(path.join(SRC, input)).webp({ quality: 80 }).toFile(path.join(OUT, output))
    console.log('done:', output)
  } catch {
    /* stills not present: skip */
  }
}
